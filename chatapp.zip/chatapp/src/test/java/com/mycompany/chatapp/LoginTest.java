package com.mycompany.chatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    Login login = new Login();

    // =========================
    // USERNAME TESTS
    // =========================

    @Test
    public void testValidUsername() {
        assertTrue(login.checkUsername("kyl_e"));
    }

    @Test
    public void testInvalidUsername_NoUnderscore() {
        assertFalse(login.checkUsername("kyle"));
    }

    @Test
    public void testInvalidUsername_TooLong() {
        assertFalse(login.checkUsername("kyleeeee"));
    }

    // =========================
    // PASSWORD TESTS
    // =========================

    @Test
    public void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99"));
    }

    @Test
    public void testInvalidPassword_NoCapital() {
        assertFalse(login.checkPasswordComplexity("ch&&sec@ke99"));
    }

    @Test
    public void testInvalidPassword_NoNumber() {
        assertFalse(login.checkPasswordComplexity("Ch&&sec@ke"));
    }

    @Test
    public void testInvalidPassword_NoSpecialChar() {
        assertFalse(login.checkPasswordComplexity("ChSecake99"));
    }

    @Test
    public void testInvalidPassword_TooShort() {
        assertFalse(login.checkPasswordComplexity("Ch9!a"));
    }

    // =========================
    // PHONE NUMBER TESTS
    // =========================

    @Test
    public void testValidPhoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testInvalidPhoneNumber_NoCountryCode() {
        assertFalse(login.checkCellPhoneNumber("0838968976"));
    }

    @Test
    public void testInvalidPhoneNumber_TooLong() {
        assertFalse(login.checkCellPhoneNumber("+27838968976000"));
    }

    // =========================
    // REGISTER USER TESTS
    // =========================

    @Test
    public void testRegisterUser_Success() {
        String result = login.registerUser("kyl_e", "Ch&&sec@ke99", "+27838968976");
        assertEquals("User registered successfully.", result);
    }

    @Test
    public void testRegisterUser_InvalidUsername() {
        String result = login.registerUser("kyle", "Ch&&sec@ke99", "+27838968976");
        assertTrue(result.contains("Username is not correctly formatted"));
    }

    @Test
    public void testRegisterUser_InvalidPassword() {
        String result = login.registerUser("kyl_e", "password", "+27838968976");
        assertTrue(result.contains("Password is not correctly formatted"));
    }

    @Test
    public void testRegisterUser_InvalidPhone() {
        String result = login.registerUser("kyl_e", "Ch&&sec@ke99", "0838968976");
        assertTrue(result.contains("Cell phone number incorrectly formatted"));
    }

    // =========================
    // LOGIN TESTS
    // =========================

    @Test
    public void testLoginSuccess() {
        login.registerUser("kyl_e", "Ch&&sec@ke99", "+27838968976");

        assertTrue(login.loginUser("kyl_e", "Ch&&sec@ke99"));
    }

    @Test
    public void testLoginFail_WrongPassword() {
        login.registerUser("kyl_e", "Ch&&sec@ke99", "+27838968976");

        assertFalse(login.loginUser("kyl_e", "wrongpass"));
    }

    @Test
    public void testReturningLoginStatus_Success() {
        login.registerUser("kyl_e", "Ch&&sec@ke99", "+27838968976");

        assertEquals(
                "Welcome kyl_e, it is great to see you again.",
                login.returningLoginStatus(true)
        );
    }

    @Test
    public void testReturningLoginStatus_Fail() {
        assertEquals(
                "Username or password incorrect, please try again.",
                login.returningLoginStatus(false)
        );
    }
}